package com.envestnet.ignite.jdbc;

import java.util.List;

public interface EmployeeDaoInterface {
	void add(Employee employee);
	
	Employee searchById(int id);
	

	Employee searchByDeptName(String name);
	
	List<Employee> getAll();
}
