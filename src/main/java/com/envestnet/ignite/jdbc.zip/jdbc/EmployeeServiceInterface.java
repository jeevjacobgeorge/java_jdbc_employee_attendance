package com.envestnet.ignite.jdbc;

import java.util.List;

public interface EmployeeServiceInterface {


	void addEmployee(Employee employee);
	
	Employee searchEmployeeById(int id);
	
	Employee searchEmployeeByDeptName(String name);
	
	List<Employee> listEmployees();
}
